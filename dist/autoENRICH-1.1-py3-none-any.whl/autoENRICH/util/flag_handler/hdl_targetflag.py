# Copyright 2020 Will Gerrard
#This file is part of autoENRICH.

#autoENRICH is free software: you can redistribute it and/or modify
#it under the terms of the GNU Affero General Public License as published by
#the Free Software Foundation, either version 3 of the License, or
#(at your option) any later version.

#autoENRICH is distributed in the hope that it will be useful,
#but WITHOUT ANY WARRANTY; without even the implied warranty of
#MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#GNU Affero General Public License for more details.

#You should have received a copy of the GNU Affero General Public License
#along with autoENRICH.  If not, see <https://www.gnu.org/licenses/>.

from autoENRICH.reference.periodic_table import Get_periodic_table

def flag_to_target(flag):

	p_table = Get_periodic_table()
	if len(flag) == 4:
		if str(flag[0]) == 'J':
			length = int(flag[1])
		else:
			length = int(flag[0])
		atype1 = int(p_table.index(str(flag[2])))
		atype2 = int(p_table.index(str(flag[3])))

		if atype1 >= atype2:
			return [length, atype1, atype2]
		else:
			return [length, atype2, atype1]

	elif len(flag) == 3:
		atype = int(p_table.index(str(flag[0])))
		return [atype]

	else:
		print('flag, ', flag, ' not recognised, coupling flag format is <nJxy> . . .')
		print('flag, ', flag, ' not recognised, chemical shift flag format is <XCS> . . .')
		return 0

def target_to_flag(target):
	p_table = Get_periodic_table()

	if len(target) == 3:
		flag = str(target[0]) + 'J' + str(p_table[target[1]]) + str(p_table[target[2]])
	elif len(target) == 1:
		flag = str(target[0]) + 'CS'
	else:
		print('Error, target ', target, ' not recognised')

	return flag
